

    <!-- Slider Start -->
    <div id="rev_slider_35_1_wrapper" class="rev_slider_wrapper fullwidthbanner-container  hidden-xs" data-alias="news-gallery35" style="margin:0px auto;background-color:#ffffff;padding:0px;margin-top:0px;margin-bottom:0px;width: 565px !important;">
        <!-- START REVOLUTION SLIDER 5.0.7 fullwidth mode -->
        <div id="rev_slider_35_1" class="rev_slider fullwidthabanner" style="display:none;" data-version="5.0.7">
            <ul>
                <!-- SLIDE  -->
                <li data-index="rs-129" data-transition="fade" data-slotamount="default" data-rotate="0" data-fstransition="fade" data-fsmasterspeed="1500" data-fsslotamount="7" data-title="<span>1</span>Co-creation" data-description="Collaborative community" style="margin-top: -75px !important;">
                    <!-- MAIN IMAGE -->
                    <img src="images/finance/bg.png" alt="" data-bgposition="center center" data-bgfit="cover" data-bgrepeat="no-repeat" class="rev-slidebg" data-no-retina>
                    <!-- LAYERS -->
                    <h1 class="tp-caption  tp-resizeme text-center color_white text_bold p-48" data-x="center" data-y="245" data-width="full" data-transform_idle="o:1;" data-transform_in="y:[-200%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;s:1500;e:Power3.easeInOut;" data-transform_out="auto:auto;s:1000;e:Power3.easeInOut;" data-mask_in="x:0px;y:0px;s:inherit;e:inherit;" data-mask_out="x:0;y:0;s:inherit;e:inherit;" data-start="800">Impact Unlimited</h1>

                    <div class="tp-caption  tp-resizeme text-center" data-x="center" data-y="300" data-width="full" data-transform_idle="o:1;" data-transform_in="y:[-200%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;s:1500;e:Power3.easeInOut;" data-transform_out="auto:auto;s:1000;e:Power3.easeInOut;" data-mask_in="x:0px;y:0px;s:inherit;e:inherit;" data-mask_out="x:0;y:0;s:inherit;e:inherit;" data-start="800">
                        <p class="p_20 color_white">Join the most energetic community of change makers in Nigeria.</p>
                    </div>

                    <div class="tp-caption  tp-resizeme text-center" data-x="center" data-y="380" data-width="full" data-transform_idle="o:1;" data-transform_in="y:[-200%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;s:1500;e:Power3.easeInOut;" data-transform_out="auto:auto;s:1000;e:Power3.easeInOut;" data-mask_in="x:0px;y:0px;s:inherit;e:inherit;" data-mask_out="x:0;y:0;s:inherit;e:inherit;" data-start="800"> <a href="#s_services" class="btn-whitw">Learn More</a> <a href="contact" class="btn-light">Contact Us</a>
                    </div>

                </li>

                <li data-index="rs-130" data-transition="slideleft" data-slotamount="default" data-rotate="0" data-title="<span>2</span>Mentoring" data-description="Grooming next generation entreprenuers" style="margin-top: -75px !important;"> <img src="images/finance/bg_3.png" alt="" data-bgposition="center center" data-bgfit="cover" data-bgrepeat="no-repeat" class="rev-slidebg" data-no-retina>

                    <!-- LAYERS -->
                    <h1 class="tp-caption  tp-resizeme text-center color_white text_bold p-48" data-x="center" data-y="245" data-width="full" data-transform_idle="o:1;" data-transform_in="y:[-200%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;s:1500;e:Power3.easeInOut;" data-transform_out="auto:auto;s:1000;e:Power3.easeInOut;" data-mask_in="x:0px;y:0px;s:inherit;e:inherit;" data-mask_out="x:0;y:0;s:inherit;e:inherit;" data-start="800">Get expert business support</h1>

                    <div class="tp-caption  tp-resizeme text-center" data-x="center" data-y="300" data-width="full" data-transform_idle="o:1;" data-transform_in="y:[-200%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;s:1500;e:Power3.easeInOut;" data-transform_out="auto:auto;s:1000;e:Power3.easeInOut;" data-mask_in="x:0px;y:0px;s:inherit;e:inherit;" data-mask_out="x:0;y:0;s:inherit;e:inherit;" data-start="800">
                        <p class="p_20 color_white">Become an exceptional entrepreneur by being a part of wennovation mentorship program.</p>
                    </div>

                    <div class="tp-caption  tp-resizeme text-center" data-x="center" data-y="380" data-width="full" data-transform_idle="o:1;" data-transform_in="y:[-200%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;s:1500;e:Power3.easeInOut;" data-transform_out="auto:auto;s:1000;e:Power3.easeInOut;" data-mask_in="x:0px;y:0px;s:inherit;e:inherit;" data-mask_out="x:0;y:0;s:inherit;e:inherit;" data-start="800"> <a href="#s_services" class="btn-whitw">Learn More</a> <a href="contact" class="btn-light">Contact Us</a>
                    </div>
                </li>

                <li data-index="rs-131" data-transition="slideleft" data-rotate="0" data-title="<span>3</span> Startup Funding" data-description="We guide funding of seeded businesses"  style="margin-top: -75px !important;"> <img src="images/finance/bg_5.png" alt="" data-bgposition="center center" data-bgfit="cover" data-bgrepeat="no-repeat" class="rev-slidebg" data-no-retina>
                   
                    <!-- LAYERS -->
                    <h1 class="tp-caption  tp-resizeme text-center color_white text_bold p-48" data-x="center" data-y="245" data-width="full" data-transform_idle="o:1;" data-transform_in="y:[-200%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;s:1500;e:Power3.easeInOut;" data-transform_out="auto:auto;s:1000;e:Power3.easeInOut;" data-mask_in="x:0px;y:0px;s:inherit;e:inherit;" data-mask_out="x:0;y:0;s:inherit;e:inherit;" data-start="800">Raise Seed fund for your business</h1>

                    <div class="tp-caption  tp-resizeme text-center" data-x="center" data-y="300" data-width="full" data-transform_idle="o:1;" data-transform_in="y:[-200%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;s:1500;e:Power3.easeInOut;" data-transform_out="auto:auto;s:1000;e:Power3.easeInOut;" data-mask_in="x:0px;y:0px;s:inherit;e:inherit;" data-mask_out="x:0;y:0;s:inherit;e:inherit;" data-start="800">
                        <p class="p_20 color_white">Get access to seed funds by joinning wennovation's startup program.</p>
                    </div>

                    <div class="tp-caption  tp-resizeme text-center" data-x="center" data-y="380" data-width="full" data-transform_idle="o:1;" data-transform_in="y:[-200%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;s:1500;e:Power3.easeInOut;" data-transform_out="auto:auto;s:1000;e:Power3.easeInOut;" data-mask_in="x:0px;y:0px;s:inherit;e:inherit;" data-mask_out="x:0;y:0;s:inherit;e:inherit;" data-start="800"> <a href="#s_services" class="btn-whitw">Learn More</a> <a href="contact" class="btn-light">Contact Us</a>
                    </div>
                </li>

                <li data-index="rs-132" data-transition="slideleft" data-rotate="0" data-title="<span>4</span> Entrepreneurship" data-description="We drive entrepreneurship"  style="margin-top: -75px !important;"> <img src="images/finance/bg_4.png" alt="" data-bgposition="center center" data-bgfit="cover" data-bgrepeat="no-repeat" class="rev-slidebg" data-no-retina>

                    <!-- LAYERS -->
                    <h1 class="tp-caption  tp-resizeme text-center color_white text_bold p-48" data-x="center" data-y="245" data-width="full" data-transform_idle="o:1;" data-transform_in="y:[-200%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;s:1500;e:Power3.easeInOut;" data-transform_out="auto:auto;s:1000;e:Power3.easeInOut;" data-mask_in="x:0px;y:0px;s:inherit;e:inherit;" data-mask_out="x:0;y:0;s:inherit;e:inherit;" data-start="800">Build your career  as an entrepreneur</h1>

                    <div class="tp-caption  tp-resizeme text-center" data-x="center" data-y="300" data-width="full" data-transform_idle="o:1;" data-transform_in="y:[-200%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;s:1500;e:Power3.easeInOut;" data-transform_out="auto:auto;s:1000;e:Power3.easeInOut;" data-mask_in="x:0px;y:0px;s:inherit;e:inherit;" data-mask_out="x:0;y:0;s:inherit;e:inherit;" data-start="800">
                        <p class="p_20 color_white">Kickstart your journey as an entrepreneur with wennovation's startup co-creation space.</p>
                    </div>

                    <div class="tp-caption  tp-resizeme text-center" data-x="center" data-y="380" data-width="full" data-transform_idle="o:1;" data-transform_in="y:[-200%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;s:1500;e:Power3.easeInOut;" data-transform_out="auto:auto;s:1000;e:Power3.easeInOut;" data-mask_in="x:0px;y:0px;s:inherit;e:inherit;" data-mask_out="x:0;y:0;s:inherit;e:inherit;" data-start="800"> <a href="#s_services" class="btn-whitw">Learn More</a> <a href="contact" class="btn-light">Contact Us</a>
                    </div>
                </li>
                <!-- SLIDE  -->
            </ul>
        </div>
    </div>
    <!-- Slider End -->

    <!-- Services Start -->
    <section id="s_services" class="p-t-100 p-b-100">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="heading">
                        <div class="heading_border bg_red"></div>
                        <p>What We Do</p>
                        <h2>Our <span class="color_red">Services</span></h2>
                    </div>
                </div>
            </div>

            <div class="row p-t-10 m-b-10">
                <div class="col-md-12">

                    <div id="services_slider" class="owl-carousel">

                        <div class="item">
                            <div class="services">
                                <div class="image_s">
                                    <a>
                                        <img src="images/finance/consult.jpg" alt="Owl Image"></a>
                                </div>
                                <h3 class="text-uppercase"><span>1</span>Consulting</h3>
                                <p>We help to improve their performance, operating primarily through the analysis of existing organizational problems and the development of plans for improvement.</p>
                            </div>
                        </div>

                        <div class="item">
                            <div class="services">
                                <div class="image_s">
                                    <a>
                                        <img src="images/finance/incubation.jpg" alt="Owl Image"></a>
                                </div>
                                <h3 class="text-uppercase"><span>2</span>Incubation</h3>
                                <p>We help new and startup companies to develop by providing services such as management training, co-creation work space and business support.</p>
                            </div>
                        </div>

                        <div class="item">
                            <div class="services">
                                <div class="image_s">
                                    <a>
                                        <img src="images/finance/space.jpg" alt="Owl Image"></a>
                                </div>
                                <h3 class="text-uppercase"><span>3</span>Workspace</h3>
                                <p>We provide a shared work environment where people meet, work, network, share ideas and collaborate on projects.</p>
                            </div>
                        </div>

                    </div>

                </div>
            </div>

        </div>
        
    </section>
    <!-- Services End -->

    <!-- BG + Text _3 Start -->
    
        <div id="represent">
    <section id="finance_bg_text_2">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <h2>We are grooming the <span class="color_red">NEXT</span><br> set of African businesses</h2>
                    
                        <p class="color_white">We create a sustainable eco-system that uses non-profit model to train social
                            <br> entrepreneurs but for-profit model to guide development & funding of seeded businesses.</p>
                </div>
            </div>
        </div>
    </section>
    </div>
    <!-- BG + Text _3 End -->

    
    <!-- Our Team Start -->
    <section id="our_team_3" class="p-t-50 m-b-10">
        <div class="container">
            
            
        <div class="container">
            <div class="row">
                <div class="col-md-12 text-center">
                    <div class="heading">
                        <div class="heading_border_1 bg_red"></div>
                        <p>OUR TEAM</p>
                        <h2>The minds behind <span class="color_red">wennovation</span></h2>
                    </div>
                </div>
            </div>
        </div>

            <hr class="hrr">
            <div id="our_team_slider_3" class="owl-carouse p-t-20">

                <div class="item" style="width: 350px !important; padding: 30px;">

                    <div class="single-effect">
                        <figure class="wpf-demo-gallery">
                            <a><img src="images/team/Idris.jpg" alt="img"></a>
                        </figure>
                    </div>
                    <div class="team_text">
                        <h3>Idris Ayodeji Bello</h3>
                        <p>Director, Wennovation Hub</p>
                    </div>

                </div>

                <div class="item" style="width: 350px !important;  box-shadow: 0 0 17.3px 0.7px rgba(1,1,1,.1); padding: 30px;">
                    
                     <div class="single-effect">
                        <figure class="wpf-demo-gallery">
                            <a><img src="images/team/wole.jpg" alt="img"></a>
                        </figure>
                    </div>
                    <div class="team_text">
                        <h3>Oluwole Odetayo</h3>
                        <p>Founder & Executive Director, Wennovation Hub</p>
                    </div>

                </div>

                <div class="item" style="width: 350px !important; padding: 30px;">

                    <div class="single-effect">
                        <figure class="wpf-demo-gallery">
                            <a><img src="images/team/gbemi.jpg" alt="img"></a>
                        </figure>
                    </div>
                    <div class="team_text">
                        <h3>Michael Oluwagbemi</h3>
                        <p>Director, Wennovation Hub</p>
                    </div>

                </div>

            </div>
        </div>
    </section>
    <!-- Our Team end -->
    
            <hr class="hrr">
    <!-- Testinomial Start -->
    <div id="startups">
    <section id="testimonials_2" class="p-t-20 p-b-100">
        <div class="container">
            <div class="row">
                <div class="col-md-12 text-center">
                    <div class="heading">
                        <div class="heading_border_1 bg_red"></div>
                        <p>STARTUPS SUPPORTED</p>
                        <h2>Companies <span class="color_red">within our network</span></h2>
                    </div>
                </div>
            </div>
        </div>

        <div id="testimonial-slider_2" class="owl-carousel text-center">
            

            <div class="item wow fadeInDown text-center">
                <img src="images/logo/epump.png" alt="partner">

                <div class="image_text">
                    <p>Fuel Metrics is a leading software development and implementation company located in Lagos, Nigeria. They provide innovative technological solutions  and onsite training for corporate organizations.</p>
                </div>
                <div class="testi_heading">
                    <h4>Fuel Metrics</h4>
                    <p>Lagos, Nigeria</p>
                </div>
            </div>

            <div class="item wow fadeInDown text-center">
                <img src="images/logo/pro.png" alt="partner">

                <div class="image_text">
                    <p>ProNoV is the flagship offering of Opacus Tech. It is an inventory management, business intelligence and e-payment tool targeted at bottom of the pyramid retailers to enable them work smarter.</p>
                </div>
                <div class="testi_heading">
                    <h4>ProNoV</h4>
                    <p>Lagos, Nigeria</p>
                </div>
            </div>

            <div class="item wow fadeInDown text-center">
                <img src="images/logo/hutbay.png" alt="partner">

                <div class="image_text">
                    <p>Hutbay is an online real estate marketplace dedicated to helping home buyers, sellers, renters, real estate professionals and mortgage institutions find and share vital information about homes and real estate. </p>
                </div>
                <div class="testi_heading">
                    <h4>Hutbay</h4>
                    <p>Lagos, Nigeria</p>
                </div>
            </div>

            <div class="item wow fadeInDown text-center">
                <img src="images/logo/agc.png" alt="partner">

                <div class="image_text">
                    <p>Agcnigeria is a technology startup that uses technology to create solutions to the veritable problems affecting the health sector of Nigeria.</p>
                </div>
                <div class="testi_heading">
                    <h4>agcnigeria.org</h4>
                    <p>Lagos, Nigeria</p>
                </div>
            </div>

        </div>

    </section>
    </div>
    <!-- Testinomial end -->
    
    

    

    <!-- Latest News & update Start -->
    <div id="events">
    <section id="latest_news" class="p-b-100 p-t-100 bg_gray">
        <div class="container">
            <div class="row">
                <div class="col-md-8 col-sm-8 col-xs-12">
                    <div class="heading">
                                <div class="heading_border bg_red"></div>
                                <p>UPCOMING EVENTS</p>
                                <h2>Latest <span class="color_red">Events</span></h2>
                            </div>
                            
                    <div id="latest_news-slider" class="owl-carousel p-t-40">
                        <div class="item">
                            <div class="latest_box">
                                <a  href="#"><h3>AgriHack - Building the agric sector</h3></a>
                                <p>The next edition of agrihack would be holding soon...</p>
                                <div class="lates_border m-b-25"></div>
                                <span>by Wennoadmin</span>
                                <i class="icon-icons228"></i> <span>1 Feb 2017</span>
                            </div>
                        </div>
                        <div class="item">
                            <div class="latest_box">
                                <a  href="#"><h3>AgriHack - Building the agric sector</h3></a>
                                <p>The next edition of agrihack would be holding soon...</p>
                                <div class="lates_border m-b-25"></div>
                                <span>by Wennoadmin</span>
                                <i class="icon-icons228"></i> <span>1 Feb 2017</span>
                            </div>
                        </div>
                        <div class="item">
                            <div class="latest_box">
                                <a  href="#"><h3>AgriHack - Building the agric sector</h3></a>
                                <p>The next edition of agrihack would be holding soon...</p>
                                <div class="lates_border m-b-25"></div>
                                <span>by Wennoadmin</span>
                                <i class="icon-icons228"></i> <span>1 Feb 2017</span>
                            </div>
                        </div>
                        <div class="item">
                            <div class="latest_box">
                                <a  href="#"><h3>AgriHack - Building the agric sector</h3></a>
                                <p>The next edition of agrihack would be holding soon...</p>
                                <div class="lates_border m-b-25"></div>
                                <span>by Wennoadmin</span>
                                <i class="icon-icons228"></i> <span>1 Feb 2017</span>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 col-sm-4 col-xs-12">
                            <div class="heading">
                                <div class="heading_border bg_red"></div>
                                <p>Subscription</p>
                                <h2>BE UP TO <span class="color_red">date</span></h2>
                            </div>
                    <div class="p-t-40">
                        <div class="over_image"><img src="images/update_bg.png" alt="image" /></div>
                            <div class="updates">
                                <p class="color_white">Subscribe to our newsletters to receive latest news and updates. </p>
                                <form class="p-t-25">
                                    <div class="col-md-12">
                                        <input type="text" placeholder="Name">
                                    </div>
                                    <div class="col-md-10">
                                        <input type="email" class="email" placeholder="Email">
                                    </div>
                                    <div class="col-md-2">
                                        <input type="submit" class="submit" value="">
                                        <span><a href="#"><i class="icon-mail-envelope-closed3"></i></a></span>
                                    </div>
                                </form>
                            </div>

                    </div>
                </div>
            </div>
        </div>
    </section>
    </div>
    <!-- Latest News & update end -->